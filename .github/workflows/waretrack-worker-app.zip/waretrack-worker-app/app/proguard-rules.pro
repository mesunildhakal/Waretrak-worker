# El puente JS se llama por reflexión desde la página: no ofuscar.
-keepclassmembers class com.waretrack.worker.NativeBridge {
    public *;
}
