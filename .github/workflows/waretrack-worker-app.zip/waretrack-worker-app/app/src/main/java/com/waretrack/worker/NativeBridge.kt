package com.waretrack.worker

import android.webkit.JavascriptInterface

/**
 * Puente que index.html ya busca:
 *
 *   window.WareTrackNative.getServerIP()
 *   window.WareTrackNative.setServerIP(ip)
 *
 * Además expone el espejo de localStorage, que usa el script inyectado
 * assets/wt-mirror.js para que los datos del bodeguero sobrevivan a un
 * cambio de IP del servidor.
 */
class NativeBridge(private val act: MainActivity) {

    private val prefs by lazy { Prefs(act) }
    private val mirror by lazy { LocalMirror(act) }

    // ── Descubrimiento ───────────────────────────────────────────────────

    @JavascriptInterface
    fun getServerIP(): String = prefs.serverIp ?: ""

    @JavascriptInterface
    fun setServerIP(ip: String) {
        if (ip.count { it == '.' } == 3) prefs.serverIp = ip
    }

    @JavascriptInterface
    fun getPort(): String = ServerFinder.PORT.toString()

    /** La página puede pedir un nuevo escaneo desde su botón de reconexión. */
    @JavascriptInterface
    fun rescan() = act.runOnUiThread { act.connect(force = true) }

    // ── Espejo de localStorage ───────────────────────────────────────────

    @JavascriptInterface
    fun mirrorLoad(): String = mirror.load()

    @JavascriptInterface
    fun mirrorSave(json: String) = mirror.save(json)

    @JavascriptInterface
    fun mirrorClear() = mirror.clear()

    @JavascriptInterface
    fun mirrorSize(): String = mirror.sizeBytes().toString()

    // ── Varios ───────────────────────────────────────────────────────────

    @JavascriptInterface
    fun isNativeShell(): Boolean = true

    @JavascriptInterface
    fun appVersion(): String = BuildConfig.VERSION_NAME

    @JavascriptInterface
    fun toast(msg: String) = act.toast(msg)
}
