package com.waretrack.worker

import android.content.Context
import java.io.File

/**
 * Copia del localStorage del bodeguero, guardada en el almacenamiento de la
 * app en vez de en el WebView.
 *
 * El WebView guarda localStorage por origen, así que cambiar de
 * http://192.168.1.4:8090 a http://192.168.1.7:8090 lo borra todo. Este
 * archivo no depende de la IP, así que sobrevive al cambio.
 *
 * Se escribe con archivo temporal + rename: si la app muere a mitad de
 * escritura, el respaldo anterior queda intacto.
 */
class LocalMirror(ctx: Context) {

    private val file = File(ctx.filesDir, "wt-mirror.json")
    private val tmp = File(ctx.filesDir, "wt-mirror.json.tmp")

    @Synchronized
    fun load(): String = try {
        if (file.exists()) file.readText(Charsets.UTF_8) else ""
    } catch (e: Exception) {
        ""
    }

    @Synchronized
    fun save(json: String) {
        if (json.length < 2 || json.length > MAX_BYTES) return
        try {
            tmp.writeText(json, Charsets.UTF_8)
            if (file.exists()) file.delete()
            tmp.renameTo(file)
        } catch (e: Exception) {
            try { tmp.delete() } catch (e2: Exception) { }
        }
    }

    @Synchronized
    fun clear() {
        try { file.delete() } catch (e: Exception) { }
        try { tmp.delete() } catch (e: Exception) { }
    }

    @Synchronized
    fun sizeBytes(): Long = if (file.exists()) file.length() else 0L

    companion object {
        private const val MAX_BYTES = 4 * 1024 * 1024
    }
}
