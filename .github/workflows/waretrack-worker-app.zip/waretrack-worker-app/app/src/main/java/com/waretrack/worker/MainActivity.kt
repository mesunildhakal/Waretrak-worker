package com.waretrack.worker

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var overlay: LinearLayout
    private lateinit var status: TextView
    private lateinit var spinner: ProgressBar
    private lateinit var btnRetry: Button
    private lateinit var btnManual: Button

    private lateinit var prefs: Prefs
    private var currentIp: String? = null
    private var connectJob: Job? = null
    private var loadedOk = false

    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            filePathCallback?.onReceiveValue(uris)
            filePathCallback = null
        }

    private val askPermissions =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    // ─────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)

        web = findViewById(R.id.web)
        overlay = findViewById(R.id.overlay)
        status = findViewById(R.id.status)
        spinner = findViewById(R.id.spinner)
        btnRetry = findViewById(R.id.btnRetry)
        btnManual = findViewById(R.id.btnManual)

        btnRetry.setOnClickListener { connect(force = true) }
        btnManual.setOnClickListener { askForIp() }

        setupWebView()
        requestRuntimePermissions()
        watchNetworkChanges()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else confirmExit()
            }
        })

        connect()
    }

    // ── WebView ──────────────────────────────────────────────────────────

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // localStorage: la app lo usa mucho
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            // El servidor está en la LAN: cargar siempre lo último evita el
            // clásico "el admin cambió index.html pero el celular ve lo viejo".
            cacheMode = WebSettings.LOAD_NO_CACHE
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        web.addJavascriptInterface(NativeBridge(this), "WareTrackNative")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                return false // todo se abre dentro de la app
            }

            /* Interceptamos SOLO el documento principal para inyectar el
               espejo de localStorage antes de que corra cualquier script de
               la página. Es la única forma de garantizar que los datos del
               bodeguero ya estén restaurados cuando index.html los lee. */
            override fun shouldInterceptRequest(
                view: WebView, req: WebResourceRequest
            ): WebResourceResponse? {
                if (!req.isForMainFrame) return null
                if (!req.method.equals("GET", true)) return null
                val url = req.url.toString()
                if (!url.startsWith("http://")) return null
                return try {
                    fetchWithMirror(url, req.requestHeaders)
                } catch (e: Exception) {
                    null   // si algo falla, que el WebView lo cargue normal
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (url.startsWith("http")) {
                    loadedOk = true
                    overlay.visibility = View.GONE
                    web.visibility = View.VISIBLE
                }
            }

            override fun onReceivedError(
                view: WebView, req: WebResourceRequest, error: WebResourceError
            ) {
                if (!req.isForMainFrame) return
                loadedOk = false
                // La IP cambió o el PC se apagó: volver a buscar.
                connect(force = true)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                // Cámara para el escaneo de códigos de barras.
                runOnUiThread { request.grant(request.resources) }
            }

            override fun onShowFileChooser(
                v: WebView,
                cb: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = cb
                return try {
                    fileChooser.launch(params.createIntent()); true
                } catch (e: Exception) {
                    filePathCallback = null; false
                }
            }
        }
    }

    /** El script inyectado, leído una sola vez desde assets/. */
    private val bootstrapJs: String by lazy {
        try {
            assets.open("wt-mirror.js").use { it.readBytes().toString(Charsets.UTF_8) }
        } catch (e: Exception) { "" }
    }

    private fun fetchWithMirror(url: String, headers: Map<String, String>?): WebResourceResponse? {
        if (bootstrapJs.isEmpty()) return null
        var conn: HttpURLConnection? = null
        try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 20000
                requestMethod = "GET"
                useCaches = false
                instanceFollowRedirects = true
                headers?.forEach { (k, v) ->
                    if (!k.equals("Accept-Encoding", true)) {
                        try { setRequestProperty(k, v) } catch (e: Exception) { }
                    }
                }
                setRequestProperty("Accept-Encoding", "identity")
            }
            if (conn.responseCode !in 200..299) return null
            val ctype = conn.contentType ?: ""
            if (!ctype.contains("html", true)) return null

            val html = conn.inputStream.use { it.readBytes().toString(Charsets.UTF_8) }
            val out = injectBootstrap(html)

            return WebResourceResponse(
                "text/html", "utf-8", 200, "OK",
                mapOf("Cache-Control" to "no-store"),
                ByteArrayInputStream(out.toByteArray(Charsets.UTF_8))
            )
        } catch (e: Exception) {
            return null
        } finally {
            try { conn?.disconnect() } catch (e: Exception) { }
        }
    }

    /** Mete el script justo despues de <head>, antes que todo lo demas. */
    private fun injectBootstrap(html: String): String {
        val tag = "\n<script>\n" + bootstrapJs + "\n</script>\n"
        val head = html.indexOf("<head", ignoreCase = true)
        if (head >= 0) {
            val close = html.indexOf('>', head)
            if (close > 0) return html.substring(0, close + 1) + tag + html.substring(close + 1)
        }
        return tag + html
    }

    // ── Descubrimiento ───────────────────────────────────────────────────

    fun connect(force: Boolean = false) {
        if (connectJob?.isActive == true && !force) return
        connectJob?.cancel()

        // Antes de recargar en otra IP, pedirle a la pagina que grabe su
        // localStorage en el respaldo nativo.
        if (loadedOk) {
            try { web.evaluateJavascript("window.__wtFlushMirror && window.__wtFlushMirror()", null) }
            catch (e: Exception) { }
        }

        showOverlay("Iniciando…", searching = true)

        connectJob = lifecycleScope.launch {
            val ip = ServerFinder.find(prefs.serverIp) { msg ->
                runOnUiThread { if (!loadedOk) status.text = msg }
            }

            if (ip == null) {
                showOverlay(
                    "No se encontró el servidor.\n\n" +
                        "Revisa que el PC esté encendido, que PocketBase esté corriendo " +
                        "y que el celular esté en la misma red WiFi.",
                    searching = false
                )
                return@launch
            }

            currentIp = ip
            prefs.serverIp = ip
            status.text = "Conectado a $ip"
            val url = "http://$ip:${ServerFinder.PORT}${prefs.path}?t=${System.currentTimeMillis()}"
            web.loadUrl(url)
        }
    }

    private fun showOverlay(msg: String, searching: Boolean) {
        overlay.visibility = View.VISIBLE
        web.visibility = View.GONE
        status.text = msg
        spinner.visibility = if (searching) View.VISIBLE else View.GONE
        btnRetry.visibility = if (searching) View.GONE else View.VISIBLE
        btnManual.visibility = if (searching) View.GONE else View.VISIBLE
    }

    private fun askForIp() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "192.168.1.4"
            setText(prefs.serverIp ?: "")
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("IP del PC con PocketBase")
            .setView(input)
            .setPositiveButton("Probar") { _, _ ->
                val ip = input.text.toString().trim()
                    .removePrefix("http://").removePrefix("https://")
                    .substringBefore(':').trimEnd('/')
                if (ip.isEmpty()) return@setPositiveButton
                showOverlay("Probando $ip…", searching = true)
                lifecycleScope.launch {
                    if (ServerFinder.verify(ip, 3000)) {
                        prefs.serverIp = ip
                        connect(force = true)
                    } else {
                        showOverlay("$ip no responde en el puerto ${ServerFinder.PORT}.", false)
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── Cambios de red: el bodeguero se mueve entre WiFi o el router
    //    le cambia la IP al PC. Al reconectar, revisamos y rebuscamos. ────

    private fun watchNetworkChanges() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try {
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    lifecycleScope.launch {
                        delay(1200) // dejar que la interfaz tome IP
                        val ip = currentIp
                        if (ip == null || !ServerFinder.verify(ip, 2000)) {
                            runOnUiThread { connect(force = true) }
                        }
                    }
                }
            })
        } catch (e: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        // Volver desde segundo plano tras un cambio de red.
        val ip = currentIp ?: return
        lifecycleScope.launch {
            if (!ServerFinder.verify(ip, 2500)) connect(force = true)
        }
    }

    // ── Permisos ─────────────────────────────────────────────────────────

    private fun requestRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.CAMERA)
        if (needed.isNotEmpty()) askPermissions.launch(needed.toTypedArray())
    }

    private fun confirmExit() {
        AlertDialog.Builder(this)
            .setMessage("¿Salir de WareTrack?")
            .setPositiveButton("Salir") { _, _ -> finish() }
            .setNegativeButton("Seguir", null)
            .show()
    }

    fun toast(msg: String) = runOnUiThread {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
