package com.waretrack.worker

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.SocketAddress
import java.net.URL

/**
 * Encuentra el PC que corre PocketBase dentro de la red WiFi local.
 *
 * Orden de búsqueda:
 *   1. Última IP conocida (guardada en el teléfono)  -> instantáneo el 99% de los días
 *   2. Baliza UDP opcional del PC (server/waretrack_beacon.ps1) -> instantáneo en cualquier subred
 *   3. Escaneo TCP de la subred real del teléfono    -> ~1-3 segundos
 *   4. Escaneo de subredes comunes                   -> último recurso
 */
object ServerFinder {

    const val PORT = 8090
    private const val BEACON_PORT = 45678

    private val COMMON_SUBNETS = listOf(
        "192.168.1", "192.168.0", "192.168.4", "192.168.8",
        "192.168.2", "192.168.3", "192.168.10", "192.168.100",
        "10.0.0", "10.0.1", "10.1.1", "172.16.0"
    )

    /** IPs que un router entrega con más frecuencia; se prueban primero. */
    private val PRIORITY_HOSTS = listOf(
        100, 101, 102, 103, 104, 105, 1, 2, 3, 4, 5,
        10, 11, 12, 20, 30, 50, 110, 120, 150, 200, 254
    )

    suspend fun find(
        lastKnown: String?,
        onProgress: (String) -> Unit
    ): String? = coroutineScope {

        // ── 1. Última IP conocida ────────────────────────────────────────
        if (!lastKnown.isNullOrBlank()) {
            onProgress("Conectando con $lastKnown…")
            if (verify(lastKnown, 1500)) return@coroutineScope lastKnown
        }

        // ── 2. Baliza UDP (si el PC la está emitiendo) ───────────────────
        onProgress("Buscando el servidor…")
        listenForBeacon(1500)?.let { ip ->
            if (verify(ip, 1500)) return@coroutineScope ip
        }

        // ── 3. Subred real del teléfono ──────────────────────────────────
        val mine = localSubnets()
        for (subnet in mine) {
            onProgress("Revisando la red $subnet.x …")
            scanSubnet(subnet, lastKnown)?.let { return@coroutineScope it }
        }

        // ── 4. Subredes comunes ──────────────────────────────────────────
        for (subnet in COMMON_SUBNETS) {
            if (subnet in mine) continue
            onProgress("Revisando la red $subnet.x …")
            scanSubnet(subnet, lastKnown)?.let { return@coroutineScope it }
        }

        null
    }

    // ─────────────────────────────────────────────────────────────────────
    // Verificación: no basta con que el puerto 8090 esté abierto, tiene que
    // responder como PocketBase.
    // ─────────────────────────────────────────────────────────────────────
    suspend fun verify(ip: String, timeoutMs: Int = 1500): Boolean = withContext(Dispatchers.IO) {
        var conn: HttpURLConnection? = null
        try {
            conn = (URL("http://$ip:$PORT/api/health?t=${System.currentTimeMillis()}")
                .openConnection() as HttpURLConnection).apply {
                connectTimeout = timeoutMs
                readTimeout = timeoutMs
                requestMethod = "GET"
                useCaches = false
            }
            if (conn.responseCode !in 200..299) return@withContext false
            val body = conn.inputStream.use { input ->
                val buf = ByteArrayOutputStream()
                val chunk = ByteArray(512)
                var n = input.read(chunk)
                while (n > 0 && buf.size() < 2048) {
                    buf.write(chunk, 0, n); n = input.read(chunk)
                }
                buf.toString("UTF-8")
            }
            body.contains("\"code\"")
        } catch (e: Exception) {
            false
        } finally {
            try { conn?.disconnect() } catch (e: Exception) { }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Escaneo TCP de una subred /24. Rápido: un connect() a puerto cerrado
    // en LAN falla en milisegundos.
    // ─────────────────────────────────────────────────────────────────────
    private suspend fun scanSubnet(subnet: String, lastKnown: String?): String? = coroutineScope {
        val hosts = ArrayList<Int>(254)
        lastKnown?.takeIf { it.startsWith("$subnet.") }
            ?.substringAfterLast('.')?.toIntOrNull()?.let { hosts.add(it) }
        PRIORITY_HOSTS.forEach { if (it !in hosts) hosts.add(it) }
        for (i in 1..254) if (i !in hosts) hosts.add(i)

        for (batch in hosts.chunked(64)) {
            val hits = batch.map { host ->
                async(Dispatchers.IO) {
                    val ip = "$subnet.$host"
                    if (tcpOpen(ip, 450)) ip else null
                }
            }.awaitAll().filterNotNull()

            for (ip in hits) if (verify(ip, 1500)) return@coroutineScope ip
        }
        null
    }

    private fun tcpOpen(ip: String, timeoutMs: Int): Boolean = try {
        Socket().use { s ->
            s.connect(InetSocketAddress(ip, PORT), timeoutMs)
            true
        }
    } catch (e: Exception) {
        false
    }

    // ─────────────────────────────────────────────────────────────────────
    // Subredes propias del teléfono (WiFi, o hotspot). Sin permisos extra.
    // ─────────────────────────────────────────────────────────────────────
    fun localSubnets(): List<String> {
        val out = LinkedHashSet<String>()
        try {
            for (nif in NetworkInterface.getNetworkInterfaces()) {
                if (!nif.isUp || nif.isLoopback) continue
                for (addr in nif.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress) {
                        val ip = addr.hostAddress ?: continue
                        val parts = ip.split(".")
                        if (parts.size == 4) out.add("${parts[0]}.${parts[1]}.${parts[2]}")
                    }
                }
            }
        } catch (e: Exception) { }
        return out.toList()
    }

    // ─────────────────────────────────────────────────────────────────────
    // Baliza UDP opcional: el PC emite "WARETRACK:<ip>:8090" en el puerto
    // 45678. Si no existe, esto simplemente expira y seguimos escaneando.
    // ─────────────────────────────────────────────────────────────────────
    private suspend fun listenForBeacon(timeoutMs: Long): String? = withContext(Dispatchers.IO) {
        withTimeoutOrNull(timeoutMs) {
            var socket: DatagramSocket? = null
            try {
                val s = DatagramSocket(null as SocketAddress?)
                socket = s
                s.reuseAddress = true
                s.broadcast = true
                s.soTimeout = timeoutMs.toInt()
                s.bind(InetSocketAddress(BEACON_PORT))

                val buf = ByteArray(256)
                val packet = DatagramPacket(buf, buf.size)
                s.receive(packet)

                val msg = String(packet.data, 0, packet.length).trim()
                if (msg.startsWith("WARETRACK:")) {
                    val ip = msg.removePrefix("WARETRACK:").substringBefore(":")
                    if (ip.count { c -> c == '.' } == 3) ip else null
                } else null
            } catch (e: Exception) {
                null
            } finally {
                try { socket?.close() } catch (e: Exception) { }
            }
        }
    }
}
