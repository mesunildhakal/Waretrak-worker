package com.waretrack.worker

import android.content.Context

/** Guarda la última IP del servidor para que el bodeguero nunca la escriba. */
class Prefs(ctx: Context) {

    private val sp = ctx.getSharedPreferences("waretrack", Context.MODE_PRIVATE)

    var serverIp: String?
        get() = sp.getString(KEY_IP, null)
        set(value) = sp.edit().putString(KEY_IP, value).apply()

    /** Página a abrir dentro del servidor. Editable por si algún día cambia. */
    var path: String
        get() = sp.getString(KEY_PATH, "/index.html") ?: "/index.html"
        set(value) = sp.edit().putString(KEY_PATH, value).apply()

    companion object {
        private const val KEY_IP = "server_ip"
        private const val KEY_PATH = "server_path"
    }
}
