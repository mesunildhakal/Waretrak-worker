/* ═══════════════════════════════════════════════════════════════════════
   WareTrack — espejo de localStorage
   Inyectado por la app Android ANTES de cualquier script de la página.

   Problema que resuelve: localStorage vive por origen. Cuando el router le
   cambia la IP al PC, http://192.168.1.4:8090 y http://192.168.1.7:8090 son
   dos orígenes distintos y el bodeguero pierde su nombre, su picking en
   curso y los documentos que aún no habían subido.

   Este script guarda una copia en el almacenamiento nativo de la app (que
   no depende del origen) y la restaura al abrir en una IP nueva.
   ═══════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  if (!window.WareTrackNative || typeof WareTrackNative.mirrorLoad !== 'function') return;
  if (window.__wtMirrorReady) return;
  window.__wtMirrorReady = true;

  var TS_KEY   = '__wt_mirror_ts';
  /* Cachés que se vuelven a bajar solos del servidor: no vale la pena
     copiarlas y pueden pesar megas. */
  var SKIP     = ['inv_products_cache_v1', 'inventory_data_v3'];
  var MAX_VAL  = 512 * 1024;   // por clave
  var MAX_ALL  = 3 * 1024 * 1024;

  function log(m) { try { console.info('[wt-mirror] ' + m); } catch (e) {} }

  // ── RESTAURAR ────────────────────────────────────────────────────────
  // Corre de inmediato, antes de que la página lea nada.
  try {
    var raw = WareTrackNative.mirrorLoad();
    if (raw && raw.length > 2) {
      var snap  = JSON.parse(raw);
      var mine  = parseInt(localStorage.getItem(TS_KEY) || '0', 10);
      var their = parseInt(snap[TS_KEY] || '0', 10);

      // Solo restauramos si la copia es MÁS NUEVA que lo que hay en este
      // origen. Así, volver a una IP vieja no pisa datos recientes.
      if (their > mine) {
        var n = 0;
        for (var k in snap) {
          if (!Object.prototype.hasOwnProperty.call(snap, k)) continue;
          try { localStorage.setItem(k, snap[k]); n++; } catch (e) {}
        }
        log('restauradas ' + n + ' claves desde el respaldo nativo');
        window.__wtMirrorRestored = n;
      }
    }
  } catch (e) {
    log('no se pudo restaurar: ' + e);
  }

  // ── GUARDAR ──────────────────────────────────────────────────────────
  function snapshot() {
    var out = {}, total = 0;
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (!k || k === TS_KEY) continue;
      if (SKIP.indexOf(k) !== -1) continue;
      var v = localStorage.getItem(k);
      if (v == null || v.length > MAX_VAL) continue;
      total += v.length;
      if (total > MAX_ALL) break;
      out[k] = v;
    }
    out[TS_KEY] = String(Date.now());
    return out;
  }

  var pending = null;
  function flush() {
    if (pending) { clearTimeout(pending); pending = null; }
    try {
      var snap = snapshot();
      localStorage.setItem(TS_KEY, snap[TS_KEY]);   // marca de este origen
      WareTrackNative.mirrorSave(JSON.stringify(snap));
    } catch (e) {
      log('no se pudo guardar: ' + e);
    }
  }

  function schedule() {
    if (pending) clearTimeout(pending);
    pending = setTimeout(flush, 900);              // agrupa ráfagas de escrituras
  }

  // Enganchamos los métodos nativos de localStorage para no tener que
  // tocar index.html en ningún lado.
  try {
    var proto = Object.getPrototypeOf(localStorage) || Storage.prototype;
    ['setItem', 'removeItem', 'clear'].forEach(function (name) {
      var orig = proto[name];
      if (typeof orig !== 'function' || orig.__wtWrapped) return;
      var wrapped = function () {
        var r = orig.apply(this, arguments);
        if (arguments[0] !== TS_KEY) schedule();
        return r;
      };
      wrapped.__wtWrapped = true;
      proto[name] = wrapped;
    });
  } catch (e) {
    log('no se pudieron enganchar los setters: ' + e);
  }

  // Momentos en que conviene grabar sí o sí.
  window.addEventListener('pagehide', flush);
  window.addEventListener('beforeunload', flush);
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) flush();
  });
  setInterval(flush, 30000);                       // red de seguridad

  // La app la llama justo antes de recargar por cambio de IP.
  window.__wtFlushMirror = flush;

  // Primera copia una vez que la página terminó de arrancar.
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { setTimeout(flush, 2000); });
  } else {
    setTimeout(flush, 2000);
  }

  log('espejo activo');
})();
