@echo off
REM Lanza la baliza sin ventana. Colocar junto a waretrack_beacon.ps1.
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0waretrack_beacon.ps1"
