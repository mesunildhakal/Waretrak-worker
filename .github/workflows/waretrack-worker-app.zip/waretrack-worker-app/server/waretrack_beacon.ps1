# ─────────────────────────────────────────────────────────────────────────
#  WareTrack — baliza de descubrimiento (OPCIONAL)
#
#  Anuncia por UDP la IP del PC que corre PocketBase, para que la app del
#  bodeguero la encuentre al instante sin escanear la red.
#
#  La app funciona igual sin esto: solo tarda 1-3 segundos más la primera
#  vez que la IP del PC cambia.
#
#  Probar a mano:   powershell -ExecutionPolicy Bypass -File waretrack_beacon.ps1
#  Dejar fijo:      Task Scheduler -> "Al iniciar el equipo" -> ejecutar
#                   waretrack_beacon.bat con la cuenta SYSTEM.
# ─────────────────────────────────────────────────────────────────────────

$Port = 45678
$PbPort = 8090

$udp = New-Object System.Net.Sockets.UdpClient
$udp.EnableBroadcast = $true
$endpoint = New-Object System.Net.IPEndPoint([System.Net.IPAddress]::Broadcast, $Port)

Write-Host "Baliza WareTrack activa en el puerto UDP $Port. Ctrl+C para detener."

while ($true) {
    try {
        $ip = (Get-NetIPAddress -AddressFamily IPv4 |
               Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } |
               Where-Object { $_.PrefixOrigin -ne 'WellKnown' } |
               Select-Object -First 1).IPAddress

        if ($ip) {
            $bytes = [Text.Encoding]::UTF8.GetBytes("WARETRACK:$ip`:$PbPort")
            [void]$udp.Send($bytes, $bytes.Length, $endpoint)
        }
    } catch { }
    Start-Sleep -Seconds 3
}
