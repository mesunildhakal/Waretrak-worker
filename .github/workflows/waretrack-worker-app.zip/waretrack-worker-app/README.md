# WareTrack Worker — app Android

Shell nativo para `index.html` (la app del bodeguero). Encuentra solo el PC que
corre PocketBase en la red WiFi: el bodeguero **nunca escribe una IP**.

---

## Cómo encuentra el servidor

En este orden, y se detiene en el primero que responde:

| # | Método | Tiempo | Cuándo sirve |
|---|--------|--------|--------------|
| 1 | Última IP guardada en el teléfono | ~200 ms | El 99 % de los días |
| 2 | Baliza UDP del PC (opcional) | ~1 s | La IP cambió, cualquier subred |
| 3 | Escaneo TCP de la subred real del teléfono | 1–3 s | La IP cambió, sin baliza |
| 4 | Escaneo de subredes comunes | 5–15 s | Red distinta a la habitual |
| 5 | Botón "Ingresar IP manualmente" | — | Último recurso |

No adivina la subred: la saca de la interfaz WiFi del propio teléfono, así que
funciona igual en `192.168.1.x`, `192.168.68.x`, `10.0.0.x` o en un hotspot.

Cada IP candidata se confirma pidiendo `GET /api/health` y verificando que la
respuesta venga de PocketBase, no de cualquier aparato con el puerto 8090 abierto.

**Al reconectar el WiFi** (`onAvailable`) y **al volver del segundo plano**, la app
comprueba la IP actual y, si dejó de responder, vuelve a buscar sola.

## Espejo de localStorage (sobrevive al cambio de IP)

El WebView guarda `localStorage` **por origen**. `http://192.168.1.4:8090` y
`http://192.168.1.7:8090` son dos orígenes distintos, así que cuando el router
le cambia la IP al PC, el bodeguero perdía su nombre, el picking en curso y los
documentos que todavía no habían subido.

La app ahora mantiene una copia en su propio almacenamiento, que no depende de
la IP:

- `assets/wt-mirror.js` se **inyecta dentro de `index.html`** justo después de
  `<head>`, antes de cualquier otro script. Se hace interceptando el documento
  principal (`shouldInterceptRequest`), que es la única forma de garantizar que
  los datos ya estén restaurados cuando la página los lee.
- El script engancha `setItem` / `removeItem` / `clear` y guarda una copia con
  debounce de 0,9 s. También graba al pasar a segundo plano, al cerrar, cada
  30 s, y cuando la app avisa que va a recargar en otra IP.
- Al abrir en una IP nueva, restaura solo si la copia es **más nueva** que lo
  que hay en ese origen (comparación por timestamp), así volver a una IP vieja
  no pisa datos recientes.
- No copia `inv_products_cache_v1` ni `inventory_data_v3`: son cachés que se
  vuelven a bajar del servidor y pesarían de más. Tope de 512 KB por clave y
  3 MB en total.
- Escritura con archivo temporal + rename, así que un cierre forzado a mitad de
  guardado no corrompe el respaldo.

**No reemplaza a PocketBase.** Es un respaldo del estado local del teléfono, no
una base de datos. Lo ya sincronizado sigue viviendo en el servidor.

Para vaciarlo en pruebas: `WareTrackNative.mirrorClear()` desde la consola de
Chrome DevTools (`chrome://inspect` con el celular por USB).

## Qué más resuelve

- `cacheMode = LOAD_NO_CACHE` + `?t=<timestamp>`: cuando editas `index.html` en
  `pb_public`, el celular ve la versión nueva al abrir la app. Se acaba el
  "en mi celular sigue apareciendo lo viejo".
- Puente `WareTrackNative` — `index.html` ya lo busca en su paso ①, así que la
  página recibe la IP del descubrimiento nativo sin escanear por su cuenta.
- `usesCleartextTraffic` + network security config: HTTP en LAN permitido.
- Permiso de cámara concedido al WebView (`onPermissionRequest`) para el escaneo
  de códigos de barras.
- Selector de archivos (`onShowFileChooser`) para subir fotos de evidencia.
- Botón atrás = navegar atrás dentro de la app, con confirmación para salir.

---

## Compilar

**Con Android Studio (lo más simple)**

1. `File ▸ Open` → esta carpeta.
2. Esperar el sync de Gradle (baja el wrapper y las dependencias solo).
3. `Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)`.
4. El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

**Por línea de comandos**

```bash
gradlew.bat assembleDebug          # APK de prueba
gradlew.bat assembleRelease        # APK firmado (requiere keystore)
```

Si todavía no existe `gradlew.bat`, Android Studio lo genera al hacer el primer
sync, o lo creas con `gradle wrapper`.

**APK de release firmado** — para que los próximos updates se instalen encima sin
desinstalar, guarda el keystore y usa siempre el mismo:

```bash
keytool -genkey -v -keystore waretrack.jks -keyalg RSA -keysize 2048 -validity 10000 -alias waretrack
```

Luego agrega en `app/build.gradle.kts`:

```kotlin
signingConfigs {
    create("release") {
        storeFile = file("../waretrack.jks")
        storePassword = "TU_CLAVE"
        keyAlias = "waretrack"
        keyPassword = "TU_CLAVE"
    }
}
buildTypes { getByName("release") { signingConfig = signingConfigs.getByName("release") } }
```

> ⚠️ El `applicationId` es `com.waretrack.worker`, igual que el APK anterior. Si
> aquel se firmó con otra llave, Android rechazará la instalación encima:
> desinstala el viejo una vez y listo. Se pierde el `localStorage` del WebView,
> así que conviene hacerlo con las picking lists cerradas.

## Instalar en los teléfonos

Copia el APK al celular y ábrelo, o por USB:

```bash
adb install -r app-debug.apk
```

## Baliza UDP opcional (`server/`)

Hace el descubrimiento instantáneo aunque el router le cambie la IP al PC.

1. Copia `waretrack_beacon.ps1` y `waretrack_beacon.bat` a `C:\pocketbase modi2\`.
2. Task Scheduler → tarea nueva → disparador "Al iniciar el equipo" → acción
   `waretrack_beacon.bat` → ejecutar con la cuenta SYSTEM, esté o no conectado el usuario.
3. Deja pasar UDP 45678 en el firewall de Windows (misma regla que usaste para el 8090).

La app funciona perfectamente sin la baliza.

## Notas

- **Reserva DHCP**: aunque la app se banque el cambio de IP, dejar reservada la
  del PC en el router sigue siendo lo más sano. Es un minuto en la config del router.
- **Cámara y HTTPS**: `navigator.mediaDevices` solo existe en contextos seguros.
  Sobre `http://192.168.x.x` la mayoría de las WebView lo permite, pero si el
  escaneo con cámara no abre en algún teléfono, el arreglo es servir la página
  por HTTPS o exponer un escáner nativo por el puente. Avísame y lo agrego.
- Para apuntar a otra página del servidor (por ejemplo `/admin14.html` en una
  tablet), cambia `Prefs.path`.

## Estructura

```
app/src/main/java/com/waretrack/worker/
  MainActivity.kt    WebView + overlay de conexión + inyección del espejo
  ServerFinder.kt    Descubrimiento: IP guardada → baliza → escaneo TCP
  NativeBridge.kt    window.WareTrackNative para index.html
  LocalMirror.kt     Respaldo en archivo del localStorage
  Prefs.kt           IP guardada
app/src/main/assets/
  wt-mirror.js       Script inyectado que copia y restaura localStorage
server/
  waretrack_beacon.ps1 / .bat   Baliza UDP opcional en el PC
```
